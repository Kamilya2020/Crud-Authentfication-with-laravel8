<?php $__env->startSection('content'); ?>
    <div class="bg-light p-4 rounded">
        <?php if(auth()->guard()->check()): ?>
        <a class="btn btn-lg btn-primary" href="https://meili.tn/fr/44-parfums?order=product.position.asc&resultsPerPage=24" role="button">View more products Mĕilì</a>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/home/index.blade.php ENDPATH**/ ?>