<?php $__env->startSection('content'); ?>
        <img src="a.jpg" class="css-class" alt="alt text">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project01\resources\views/home/index.blade.php ENDPATH**/ ?>