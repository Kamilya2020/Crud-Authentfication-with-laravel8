<?php $__env->startSection('content'); ?>

    <h1 class="mb-3">Mĕilì</h1>
    <h4 class="mb-4">nature & beauty</h4>

    <div class="bg-light p-4 rounded">
        <h1>Users</h1>
        <div class="lead">
            Manage your products here.
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-sm float-right">Add new product</a>
        </div>

        <div class="mt-2">
            <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col" width="1%">#</th>
                <th scope="col" width="15%">Name</th>
                <th scope="col">Description</th>
                <th scope="col" width="10%">Prices</th>
                <th scope="col" width="1%" colspan="3"></th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->description); ?></td>
                        <td><?php echo e($user->prices); ?></td>
                        <td><a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-success">Show</a></td>
                        <td><a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-secondary">Edit</a></td>
                        <td>
                            <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-warning']); ?>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="d-flex">
            <?php echo $users->links(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\project\resources\views/users/index.blade.php ENDPATH**/ ?>