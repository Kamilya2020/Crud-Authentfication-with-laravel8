@extends('layouts.app-master')

@section('content')
        <img src="a.jpg" class="css-class" alt="alt text">
@endsection
